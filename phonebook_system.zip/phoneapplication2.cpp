#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

using namespace std;

const int MAX_RECORDS = 1000;

class PhoneBookRecord
{
public:
    int srno;
    string name;
    string mobile;
    string email;
    string group;

    void inputRecord()
    {
        system("cls");
        cout << "\n\t\t********* CREATE NEW PHONE RECORD *********\n";
        cout << "\t\tEnter Serial Number: ";
        cin >> srno;
        cin.ignore();
        cout << "\t\tEnter Record Name: ";
        getline(cin, name);
        cout << "\t\tEnter Mobile Number: ";
        getline(cin, mobile);
        cout << "\t\tEnter E-Mail I.D.: ";
        getline(cin, email);
        cout << "\t\tEnter Record Group: ";
        getline(cin, group);
    }

    void displayRecord()
    {
        cout << "\n\t\t****** PHONEBOOK RECORDS ******\n";
        cout << "\t\tSr. No.    : " << srno << endl;
        cout << "\t\tName       : " << name << endl;
        cout << "\t\tMobile No. : " << mobile << endl;
        cout << "\t\tEmail ID   : " << email << endl;
        cout << "\t\tGroup      : " << group << endl;
        cout << "\n\t\t Record Display successfully \n"
             << endl;
    }
};

class PhoneBook
{
private:
    PhoneBookRecord records[MAX_RECORDS];
    int numRecords;

public:
    PhoneBook() : numRecords(0) {}

    void saveRecordsToFile()
    {
        ofstream outputFile("records_database.txt");
        if (!outputFile)
        {
            cout << "\n\t\tError: Unable to open the file for writing.\n";
            return;
        }

        for (int i = 0; i < numRecords; ++i)
        {
            outputFile << records[i].srno << endl;
            outputFile << records[i].name << endl;
            outputFile << records[i].mobile << endl;
            outputFile << records[i].email << endl;
            outputFile << records[i].group << endl;
            outputFile << endl;
        }

        outputFile.close();
        cout << "\n\t\tRecords saved to file 'records_database.txt'.\n";
    }

    void addRecord()
    {
        if (numRecords < MAX_RECORDS)
        {
            records[numRecords].inputRecord();
            numRecords++;
            saveRecordsToFile();
            cout << "\n\t\tRecord Added Successfully.\n";
        }
        else
        {
            cout << "\n\t\tPhonebook is Full. Cannot Add More Records.\n";
        }
    }

    void displayAllRecords()
    {
        loadRecordsFromFile();

        system("cls");
        cout << "\n\t\t****** ALL PHONEBOOK RECORDS ******\n";
        for (int i = 0; i < numRecords; ++i)
        {
            records[i].displayRecord();
        }
    }

    void searchRecordBySrNo(int srno)
    {
        loadRecordsFromFile();

        for (int i = 0; i < numRecords; ++i)
        {
            if (records[i].srno == srno)
            {
                records[i].displayRecord();
                return;
            }
        }
        cout << "\n\t\tRecord with Serial Number " << srno << " not found.\n";
    }

    void deleteRecordBySrNo(int srno)
    {
        loadRecordsFromFile();

        for (int i = 0; i < numRecords; ++i)
        {
            if (records[i].srno == srno)
            {
                records[i] = records[numRecords - 1];
                numRecords--;
                saveRecordsToFile();
                cout << "\n\t\tRecord Deleted Successfully.\n";
                return;
            }
        }
        cout << "\n\t\tRecord with Serial Number " << srno << " not found.\n";
    }

    void modifyRecordBySrNo(int srno)
    {
        loadRecordsFromFile();

        for (int i = 0; i < numRecords; ++i)
        {
            if (records[i].srno == srno)
            {
                records[i].inputRecord();
                saveRecordsToFile();
                cout << "\n\t\tRecord Modified Successfully.\n";
                return;
            }
        }
        cout << "\n\t\tRecord with Serial Number " << srno << " not found.\n";
    }

    void loadRecordsFromFile()
    {
        ifstream inputFile("records_database.txt");
        if (!inputFile)
        {
            cout << "\n\t\tNo records file found.\n";
            return;
        }

        numRecords = 0;
        while (inputFile >> records[numRecords].srno)
        {
            inputFile.ignore();
            getline(inputFile, records[numRecords].name);
            getline(inputFile, records[numRecords].mobile);
            getline(inputFile, records[numRecords].email);
            getline(inputFile, records[numRecords].group);
            numRecords++;
        }
        inputFile.close();
        cout << "\n\t\tRecords loaded from file.\n";
    }

    void sortRecordsBySrNo()
    {
        loadRecordsFromFile();


        std::sort(records, records + numRecords, [](const PhoneBookRecord &a, const PhoneBookRecord &b)
                  { return a.srno < b.srno; });

        saveRecordsToFile();
        cout << "\n\t\tRecords sorted by Serial Number.\n";
        displayAllRecords();
    }

    void displayIntro()
    {
        cout << "\n+------------------------------------------------------------------------+";
        cout << "\n|                                                                        |";
        cout << "\n|                                                                        |";
        cout << "\n \xB1\xB1\xB1\xB1\xB1\xB1\xB1\xB1\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2 WELCOME TO PHONEBOOK MANAGEMENT SYSTEM \xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB1\xB1\xB1\xB1\xB1\xB1\xB1\xB1\n";
        cout << "\n|                                                                        |";
        cout << "\n|                                                                        |";
        cout << "\n+------------------------------------------------------------------------+\n";
    }

    void displayMenu()
    {

        cout << "\n\t\t------------------------------------\n";
        cout << "\t\t-----------------------------------\n";
        cout << "\n\t\t\t********* MENU *********\n";
        cout << "\t\t1. Add New Record\n";
        cout << "\t\t2. Display All Records\n";
        cout << "\t\t3. Search Record by Serial Number\n";
        cout << "\t\t4. Delete Record by Serial Number\n";
        cout << "\t\t5. Modify Record by Serial Number\n";
        cout << "\t\t6. Sort Contacts\n";
        cout << "\t\t0. Exit\n";
        cout << "\t\tEnter Your Choice: ";
    }
};
int main()
{
    system("color 1F");
    PhoneBook phoneBook;
    int choice;

    phoneBook.displayIntro();

    do
    {
        phoneBook.displayMenu();
        cin >> choice;
        cin.ignore();

        switch (choice)
        {
        case 0:
            cout << "\n\t\tThank you for using phonebook system.\n";
            cout << "\n\t\tExiting Phonebook Application.\n";
            return 0;
        case 1:
            phoneBook.addRecord();
            break;

        case 2:
            phoneBook.displayAllRecords();
            break;

        case 3:
        {
            int srno;
            system("cls");
            cout << "\n\t\t****** SEARCHING FOR CONTACT ******\n";
            cout << "\n\t\tEnter Serial Number to Search: ";
            cin >> srno;
            phoneBook.searchRecordBySrNo(srno);
            break;
        }

        case 4:
        {
            int srno;
            system("cls");
            cout << "\n\t\t***** DELETING CONTACT *****\n";
            cout << "\n\t\tEnter Serial Number to Delete: ";
            cin >> srno;
            phoneBook.deleteRecordBySrNo(srno);
            break;
        }

        case 5:
        {
            int srno;
            system("cls");
            cout << "\n\t\t***** MODIFYING CONTACT *****\n";
            cout << "\n\t\tEnter Serial Number to Modify: ";
            cin >> srno;
            phoneBook.modifyRecordBySrNo(srno);
            break;
        }

        case 6:
            phoneBook.sortRecordsBySrNo();
            break;

        default:
            cout << "\n\t\tInvalid Choice. Please try again.\n";
        }
    } while (choice != 6);

    return 0;
}
